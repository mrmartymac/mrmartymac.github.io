#!/bin/sh
bundle exec jekyll build

sudo cp -R /Users/martinmacdonald/Documents/GitHub/mrmartymac.github.io/_site/* /Library/WebServer/Documents/


